

<!DOCTYPE html>
<html>
<head>
	<title>Registracija</title>
</head>
<body background="https://cdn.pixabay.com/photo/2017/09/04/09/38/cross-2713356__340.jpg" style="background-size:cover">
	<h1 style="color:white">Login</h1>
	<form method="post" action="">
		<p style="color:white">Username <input type="text" name="username"/></p>
		<p style="color:white">Password <input type="password" name="password"/></p>
		<p style="color:white">Confirm Password <input type="password" name="p_password"/></p>
<?php
$i = 0;
if(isset($_POST['register'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$p_password=$_POST['p_password'];
	
	if(file_exists('users/' . $username . '.xml')){
		echo 'Vec postoji račun s istim imenom ';
		$i=$i+1;
		?><br><?php
	}
	if($username == ''){
		echo 'Username ne može biti prazan';
		$i=$i+1;
		?><br><?php
	}
	if($password == '' || $p_password == ''){
		echo 'Passwordi su prazni';
		$i=$i+1;
		?><br><?php
	}
	if($password != $p_password){
		echo 'Passwordi nisu isti';
		$i=$i+1;
		?><br><?php
	}
	if(strlen($password)<6){
		echo 'Password mora biti duži od 6 karaktera';
		$i=$i+1;
		?><br><?php
	}
	
	if($i == 0){
		$xml = new SimpleXMLElement('<user></user>');
		$xml->addChild('password',$password);
		$xml->addChild('username',$username);
		$xml->addChild('admin',0);
		$xml->asXml('users/'.$username.'.xml');
		header('Location: index.php');
		die;
	}
}

?>

		<p><input type="submit" value="Registriraj se" name="register"/></p>
	</form>

</body>
</html>