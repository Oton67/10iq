<?php
session_start();
if(!file_exists('users/'.$_SESSION['username'].'.xml')){
	header('Location: index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dobrodosli</title>
</head>
<body background="https://upload.wikimedia.org/wikipedia/commons/5/5b/Michelangelo_-_Creation_of_Adam_%28cropped%29.jpg" style="background-size:cover">
	<h1>Dobrodosli, <?php echo $_SESSION['username']; ?>, imate adminske privilegije</h1>
	
	<?php
	$directory = "users/";
	$filecount = 0;
	$files = glob($directory . "*.xml");
	if ($files){
	$filecount = count($files);
	}
	echo "Postoji $filecount računa ";
	?><br><?php
	foreach($files as $file){
		$xml =new SimpleXMLElement($file,0,true);
		
		echo 'USERNAME: ' .$xml->username. ' ';
		echo 'PASSWORD: ' .$xml->password. ' ';
		echo 'ADMIN: ' .$xml->admin. ' ';
		?><br><?php
	}
	?>
	<form method="post" action="">
		<p>Username <input type="text" name="username"/></p>
		<p><input type="submit" value="Delete" name="delete"/></p>
		<p><input type="submit" value="Admin" name="admin"/></p>
		<p><input type="submit" value="Remove Admin" name="deadmin"/></p>
	</form>
	<?php
	if(isset($_POST['delete'])){
		$username=$_POST['username'];
		if(file_exists('users/' . $username . '.xml')){
		unlink('users/' . $username . '.xml');
		?><meta http-equiv="refresh" content="0"><?php
		}
	}
	if(isset($_POST['admin'])){
		$username=$_POST['username'];
		if(file_exists('users/' . $username . '.xml')){
		$user=simplexml_load_file('users/'.$username.'.xml');
		$user->admin=1;
		$user->asXML("users/".$username.".xml");
		?><meta http-equiv="refresh" content="0"><?php
		}
	}
	
	if(isset($_POST['deadmin'])){
		$username=$_POST['username'];
		if(file_exists('users/' . $username . '.xml')){
		$usery=simplexml_load_file('users/'.$username.'.xml');
		$usery->admin=0;
		$usery->asXML("users/".$username.".xml");
		?><meta http-equiv="refresh" content="0"><?php
		}
	}
	
	?>
	<br><br>
	
	
	
	<a href="logout.php">Logout</a><br>
	<a href="changepass.php">Promijeni lozinku</a>
</body>
</html>