<?php

if(isset($_POST['login'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
		if(file_exists('users/' . $username . '.xml')){
			$xml = new SimpleXMLElement('users/' . $username . '.xml',0,true);
			if($password == $xml->password){
				if($xml->admin == '1'){
					session_start();
				$_SESSION['username'] =$username;
				header('Location: mainpageadmin.php');
				}
				if($xml->admin == '0'){
					session_start();
				$_SESSION['username'] =$username;
				header('Location: mainpage.php');
				}
				die;
			}
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body background="https://cdn.pixabay.com/photo/2017/09/04/09/38/cross-2713356__340.jpg" style="background-size:cover">
	<h1 style="color:white">Login</h1>
	<form method="post" action="">
		<p style="color:white">Username <input type="text" name="username"/></p>
		<p style="color:white">Password <input type="password" name="password"/></p>
		<p><input type="submit" value="Login" name="login"/></p>
	</form>
	<a href="register.php">Registriraj se</a>
</body>
</html>