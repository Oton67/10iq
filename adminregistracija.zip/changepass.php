<?php
$var=0;
session_start();
if(isset($_POST['changepass'])){
	$oldpass = $_POST['oldpass'];
	$password = $_POST['password'];
	$p_password = $_POST['p_password'];
	$xml = new SimpleXMLElement('users/' . $_SESSION['username'] . '.xml', 0 , true);
	if($oldpass == $xml->password)
	{
		if($password != $p_password){
		echo "Nove lozinke se ne podudaraju";
		$var = $var+1;
		?><br><?php
		}
		if(strlen($password)<6){
		echo 'Password mora biti duži od 6 karaktera';
		$var=$var+1;
		?><br><?php
		}
		if($var==0){
		$xml->password = $password;
		$xml->asXML('users/' . $_SESSION['username'] . '.xml');
		header("Location: logout.php");
		}
	}else{echo "Unijeli ste pogrešnu staru lozinku";}
	
	
}
	
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Change Pass</title>
</head>
<body background="https://cdn.pixabay.com/photo/2017/09/04/09/38/cross-2713356__340.jpg" style="background-size:cover">
	<h1>Change Password</h1>
	<form method="post" action="">
		<p>Old password <input type="password" name="oldpass"/></p>
		<p>Password <input type="password" name="password"/></p>
		<p>Confirm Password <input type="password" name="p_password"/></p>
		
		<p><input type="submit" value="Promijeni" name="changepass"/></p>
	</form>


</body>
</html>