<?php
session_start();
if(!file_exists('users/'.$_SESSION['username'].'.xml')){
	header('Location: index.php');
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Dobrodošli</title>
</head>
<body background="https://cdn.pixabay.com/photo/2018/02/13/00/11/jesus-3149505_960_720.png" style="background-size:cover">
	<h1 style="color:black">Dobrodošli, <?php echo $_SESSION['username']; ?></h1>
	<hr>
	
	<img src="https://cdn3.iconfinder.com/data/icons/easter-line-1/48/09-512.png" style="width:300px;height:300px;">
	<center><h2 style="color:black">Christianity</h2></center>
	<p style="color:black">Christianity[note 1] is an Abrahamic monotheistic religion based on the life and teachings of Jesus of Nazareth. Its adherents, known as Christians, believe that Jesus Christ is the merciful Son of God and savior of all people, whose coming as the Messiah was prophesied in the Old Testament.[2] It is the world's largest religion with over 2.4 billion followers,[3] with its followers affirming that Jesus is the Logos, whose coming as the Messiah was prophesied in the Hebrew scriptures and chronicled in the New Testament.

Christianity began as a Second Temple Judaic sect, in the 1st century, in the Roman province of Judea. Jesus' apostles, and their followers, spread it around Syria, Europe, Anatolia, Mesopotamia, Transcaucasia, Egypt, Ethiopia, and Asia, despite initial persecution. It soon also attracted Gentile God-fearers, which lead to a departure from Jewish customs, and the establishment of Christianity as an independent religion. Emperor Constantine the Great converted to Christianity and decriminalized it in the Edict of Milan (313), later convening the Council of Nicaea (325) where Early Christianity was consolidated into what would become the state religion of the Roman Empire (380). The early history of Christianity sometimes referred to as the Great Church, the united communion of the "orthodox" Christian churches before their schisms. Oriental Orthodoxy split after the Council of Chalcedon (451) over differences in Christology,[4] while the Eastern Orthodox Church and the Catholic Church separated in the East–West Schism (1054), especially over the authority of the Bishop of Rome. Similarly, Protestantism split in numerous denominations from the Catholic Church in the Protestant Reformation (16th century) over theological and ecclesiological disputes, most predominantly on the issue of justification and papal primacy. Following the Age of Discovery (15th–17th century), Christianity was spread into the Americas, Oceania, sub-Saharan Africa, and the rest of the world via missionary work.[5][6][7]

Christianity remains culturally diverse in its Western and Eastern branches, as well as in its doctrines concerning justification and the nature of salvation, ecclesiology, ordination, and Christology. The four largest branches of Christianity are the Catholic Church (1.3 billion), Protestantism (920 million), the Eastern Orthodox Church (260 million) and Oriental Orthodoxy (86 million), amid various efforts toward ecumenism [8] Their theology and professions of faith, in addition to the Bible, generally hold in common that Jesus suffered, died, was buried, descended into the grave and rose from the dead to grant eternal life to those who believe in him for the forgiveness of their sins. His incarnation, earthly ministry, crucifixion and resurrection are often referred to as the gospel, meaning the "good news". Describing Jesus' life and teachings are the four canonical gospels of Matthew, Mark, Luke and John, with the Jewish Old Testament as the Gospel's respected background.

Christianity and Christian ethics played a prominent role in the development of Western civilization,[9][10][11][12][13] particularly around Europe during late antiquity and the Middle Ages. Despite a decline in membership in the West,[14] Christianity remains the dominant religion in the region, with more than 70% of the population identifying as Christian.[15] Christianity is growing rapidly in Africa and Asia, the world's most populous continents.[16]</p>
	<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Ut-UOhY0s8E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
	<center><h2 style="color:black"> God in Christianity </h2></center>
	<p style="color:black">God in Christianity is the eternal being who created and preserves all things. Christians believe God to be both transcendent (wholly independent of, and removed from, the material universe) and immanent (involved in the world).[1][2] Christian teachings of the immanence and involvement of God and his love for humanity exclude the belief that God is of the same substance as the created universe[3] but accept that God's divine nature was hypostatically united to human nature in the person of Jesus Christ, in an event known as the Incarnation.

Early Christian views of God were expressed in the Pauline epistles and the early creeds, which proclaimed one God and the divinity of Jesus, almost in the same breath as in 1 Corinthians (8:5-6): "For even if there are so-called gods, whether in heaven or on earth (as indeed there are many 'gods' and many 'lords'), yet for us there is but one God, the Father, from whom all things came and for whom we live; and there is but one Lord, Jesus Christ, through whom all things came and through whom we live."[4][5][6] "Although the Judeo-Christian sect of the Ebionites protested against this apotheosis of Jesus,[7] the great mass of Gentile Christians accepted it."[8] This began to differentiate the Gentile Christian views of God from traditional Jewish teachings of the time.[4]

The theology of the attributes and nature of God has been discussed since the earliest days of Christianity, with Irenaeus writing in the 2nd century: "His greatness lacks nothing, but contains all things".[9] In the 8th century, John of Damascus listed eighteen attributes which remain widely accepted.[10] As time passed, theologians developed systematic lists of these attributes, some based on statements in the Bible (e.g., the Lord's Prayer, stating that the Father is in Heaven), others based on theological reasoning.[11][12] The Kingdom of God is a prominent phrase in the Synoptic Gospels and while there is near unanimous agreement among scholars that it represents a key element of the teachings of Jesus, there is little scholarly agreement on its exact interpretation.[13][14]

Although the New Testament does not have a formal doctrine of the Trinity as such, "it does repeatedly speak of the Father, the Son, and the Holy Spirit... in such a way as to compel a Trinitarian understanding of God." This never becomes a tritheism, i.e. this does not imply three Gods.[15] Around the year 200, Tertullian formulated a version of the doctrine of the Trinity which clearly affirmed the divinity of Jesus and came close to the later definitive form produced by the Ecumenical Council of 381.[16][17] The doctrine of the Trinity can be summed up as: "The One God exists in Three Persons and One Substance, as God the Father, God the Son and God the Holy Spirit."[18][19] Trinitarians, who form the large majority of Christians, hold it as a core tenet of their faith.[20][21] Nontrinitarian denominations define the Father, the Son, and the Holy Spirit in a number of different ways.[22]</p>
	
	
	<p><a href="changepass.php">Promijeni lozinku</a></p>
	<p><a href="logout.php">Logout</a></p>
</body>
</html>